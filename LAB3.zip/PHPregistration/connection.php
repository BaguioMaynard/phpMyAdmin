<?php
$conn =  mysqli_connect("localhost","id17895578_tester","oy34|lMS[})Ez=Kj","id17895578_test")or die("Could not connect :" );
if($conn)
echo"Successful connection ";

?>