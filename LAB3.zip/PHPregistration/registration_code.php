<!--
Here, we write code for registration.
-->
<?php
require_once('connection.php');

$fname =$mname = $lname =$gender =$username =$password = $status = '';



$fname = $_POST['firstname'];
$mname = $_POST['middlename'];
$lname = $_POST['lastname'];
$gender = $_POST['gender'];
$username = $_POST['username'];
$password = $_POST['password'];
$status = $_POST['status'];



$data = $_POST;

if (empty($data['firstname']) ||
    empty($data['middlename']) ||
    empty($data['lastname']) ||
    empty($data['gender']) ||
	empty($data['username']) ||
	empty($data['password']) ||
	empty($data['status']))
	{
    
    die(<html>
    <head>
    
        <H2> Sorry something is missing </H2>
        <H3>Please fill all required fields!</H3>
      
    </head>
    </html>);
}
$sql = "INSERT INTO dataform ( firstname, middlename, lastname, gender, username, password, status)
VALUES('$fname','$mname','$lname','$gender','$username','$password','$status')";

$result=mysqli_query($conn,$sql);
if($result)
{
	header("Location: submit.php");
}
else
{
	echo "Error :".$sql;
}

?>