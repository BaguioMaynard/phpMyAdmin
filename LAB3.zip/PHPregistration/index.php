<!--
Here, we write code for registration.
-->

<!--
Into this file, we create a layout for registration page.
-->


<div id="frmRegistration">

<form class="form-horizontal" action="registration_code.php" method="POST">
	<h1>USER REGISTRATION FORM </h1>

	<div class="form-group">
    <label class="control-label col-sm-2" for="firstname">First Name:</label>
    <div class="col-sm-6">
      <input type="text" name="firstname" class="form-control" id="firstname" placeholder="Enter Firstname">
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-2" for="middlename">Middlename:</label>
    <div class="col-sm-6">
      <input type="text" name="middlename" class="form-control" id="middlename" placeholder="Enter Middlename">
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-2" for="lastname">Last Name:</label>
    <div class="col-sm-6">
      <input type="text" name="lastname" class="form-control" id="lastname" placeholder="Enter Lastname">
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-2" for="gender">Gender:</label>
    <div class="col-sm-6">
      <label class="radio-inline"><input type="radio" name="gender" value="Male">Male</label>
	  <label class="radio-inline"><input type="radio" name="gender" value="Female">Female</label>
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-2" for="username">Username:</label>
    <div class="col-sm-6">
      <input type="username" name="username" class="form-control" id="username" placeholder="Enter username">
    </div>
  </div>
  
  <div class="form-group">
    <label class="control-label col-sm-2" for="password">Password:</label>
    <div class="col-sm-6"> 
      <input type="password" name="password" class="form-control" id="password" placeholder="Enter password">
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-2" for="stat">Status:</label>
    <div class="col-sm-6">
      <label class="radio-inline"><input type="radio" name="status" value="Single">Single</label>
	  <label class="radio-inline"><input type="radio" name="status" value="Taken">Taken</label>
    </div>
  </div>
  
  <div class="form-group"> 
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" name="create" class="btn btn-primary">Submit</button>
    </div>
  </div>
  <div class="col-sm-offset-2 col-sm-10">
      <button type="reset" name="create" class="btn btn-primary">Reset</button>
    </div>
  </div>
</form>
</div>


